# BSMGaming チーム管理システム

Streamlit 製のチーム活動履歴・メンバー管理アプリです。

## 主な機能
- メンバーログイン、権限（オーナー / 管理者 / 一般）
- オーナーの認証アプリによる TOTP 二段階認証
- PBKDF2-SHA256 によるパスワードハッシュ保存
- 日付ごとの活動履歴の投稿・表示・検索
- CSV エクスポート
- メンバー登録、無効化、有効化、権限変更、パスワード再設定
- メンテナンス時間設定（日本時間）
- 背景色、文字色、アイコンの設定
- ログイン試行回数の制限

## ローカルで起動
Python 3.11 以降を推奨します。

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OWNER_ID="自分のオーナーID"
export OWNER_PASSWORD="十分に長い新しいパスワード"
streamlit run app.py
```

Windows PowerShell の場合は環境変数を次のように設定します。

```powershell
$env:OWNER_ID="自分のオーナーID"
$env:OWNER_PASSWORD="十分に長い新しいパスワード"
streamlit run app.py
```

初回起動時、オーナーアカウントが作成されます。最初のログインで認証アプリの設定画面が表示されます。画面に表示された秘密鍵を認証アプリへ登録し、6桁コードで確認してください。秘密鍵はパスワードと同様に秘密に保管してください。

データベースを指定しない場合はローカルの `bsmgaming_team.db` を使用します。これは開発用です。

## チーム全員向けに公開する場合
**永続化された PostgreSQL データベースを必ず用意してください。** ホスティング先のローカルファイルは再デプロイ時に消えることがあるため、公開環境で SQLite を使わないでください。

ホスティング環境の環境変数に以下を設定します。

- `DATABASE_URL`: PostgreSQL の接続 URL
- `OWNER_ID`: オーナーのユーザーID
- `OWNER_PASSWORD`: 長くランダムな初期パスワード
- `OWNER_NAME`: 表示名（任意）
- `SESSION_TIMEOUT_MINUTES`: セッション期限（任意、既定 120）

PostgreSQL URL の例（値はホスティングサービスから取得してください）:
`postgresql://USER:PASSWORD@HOST:5432/DBNAME`

`.streamlit/secrets.toml` やソースコードへ実際のパスワード、DB 接続 URL、TOTP 秘密鍵をコミットしないでください。ホスティングサービスの Secret / Environment Variables 機能を使用してください。

## Streamlit Community Cloud の例
1. このフォルダーの内容を、自分の非公開または公開 GitHub リポジトリにアップロードします。
2. Streamlit Community Cloud で `app.py` を指定してデプロイします。
3. PostgreSQL の外部サービスを作成し、接続 URL を `DATABASE_URL` として設定します。
4. `OWNER_ID` と `OWNER_PASSWORD` を設定して再起動します。
5. 初回ログインして TOTP を設定します。
6. オーナー設定からチームメンバーを登録します。

公開前に、チーム以外の人がアクセスできる状態でないか、招待したメンバーだけがログインできるかを確認してください。

## 注意
- このプロジェクトは公開先のアカウント作成やデプロイ操作までは自動実行しません。
- 初期オーナーのパスワードは必ず新しい値に設定してください。チャットやコードに書いた認証情報を再利用しないでください。
- アプリはインターネット上に公開されるため、PostgreSQL 側で TLS 接続を使用し、バックアップを設定してください。
- これは基本的なチーム管理アプリです。高い機密性が必要なデータは保存しないでください。
